
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.shortcuts import render, redirect
from django.urls import reverse
from .forms import *

from .models import Category, Product, Client, Order


def index(request):
    cat_list = Category.objects.all().order_by('id')[:10]
   # product_list = Product.objects.all().order_by('price')[:5]
    #response = HttpResponse()
    #heading1 = '<p><center>' + 'List of categories: ' + '</center></p>'
    #response.write(heading1)
    #   para = '<p>' + str(category.id) + ': ' + str(category) + '</p>'
     #   response.write(para)
    #heading2 = '<p><center>' + 'List of Products: ' + '</center></p>'
    #response.write(heading2)
    #for product in product_list[::-1]:
     #   pro = '<p>' + str(product.name) + ': ' + str(product.price) + '</p>'
      #  response.write(pro)
    return render(request, 'myapp/index.html', {'cat_list': cat_list})


def about(request):
    #response = HttpResponse()
    #text = '<p>This is an Online Store App</p>'
    #response.write(text)
    return render(request, 'myapp/about.html')


def detail(request, cat_no):
    #response = HttpResponse()
    details = get_object_or_404(Category, id=cat_no)
    #text1 = '<p>'+str(details.name)+': ' + str(details.warehouse)+'</p>'
    #response.write(text1)
    product_details = Product.objects.filter(category_id=cat_no)
    #for product in product_details:
       #pro = '<p>' + str(product.name) + ': ' + str(product.price) + '</p>'
       #response.write(pro)
    return render(request, 'myapp/detail.html', {'details': details, 'product_details': product_details})


def products(request):
    prodlist = Product.objects.all().order_by('id')[:10]
    return render(request, 'myapp/products.html', {'prodlist': prodlist})


def place_order(request):
    msg = ''
    prodlist = Product.objects.all()
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            if order.num_units <= order.product.stock:
                order.save()
                msg = 'Order placed succesfully.'
            else:
                msg = 'We dont have sufficient stock to fill your order.'
            return render(request, 'myapp/order_response.html' , {'msg':msg})
    else:
        form = OrderForm()
    return render(request, 'myapp/placeorder.html', {'form':form, 'msg':msg, 'prodlist':prodlist})


def productdetail(request, prod_id):
    product = Product.objects.get(pk=prod_id)
    if request.method == 'POST':
        form = InterestForm(request.POST)
        if form.is_valid():
            data = form.data
            print('Interested:', data.get('interested'), data.get('quantity'))
            if data.get('interested') == '1':
                print('ProductInt', product.intrested)
                product.intrested = product.intrested + 1
            product.save()
        return redirect('myapp:index')
    else:
        form = InterestForm()
    return render(request, 'myapp/productdetail.html', {'form':form, 'product':product})
    # return render(request, 'myapp/productdetail.html', {'product':product})